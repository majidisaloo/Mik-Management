# Database Configuration Directory

This folder stores `database.config.json`, which is generated automatically the first time the backend boots. The file contains the data file path and the random `databasePassword` pepper required to validate user logins. Do not commit the generated JSON file to Git.
